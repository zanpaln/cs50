#include <cs50.h>

#include "helpers.h"

bool search(int value, int values[], int n)
{
    int min = 0;
    int max = n;
    
    while (max >= min)
    {    
        int mid = (int) min + (max-min)/2;
        
        if (values[mid] < value)
            min = mid + 1;
        else if (values[mid] > value)
            max = mid - 1;
        else
            return true;
    }
    return false;
}
//Selection sort
void sort(int values[], int n)
{
    for (int i = 0; i < n; i++)
    {
        int min = i;
        
        for( int j = i + 1; j<n; j++)
        {
            if(values[min] > values[j])
                min = j;
        }
        
        if(min != i)
        {
            int temp = values[i];
            values[i] = values[min];
            values[min] = temp; 
        }
    }
    return;
}
//Buble sort
void buble_sort(int values[], int n)
{
    for(int i = 0; i < n - 1; i++)
    {
        for(int j = 0; j < n - i - 1; j++)
        {
            if(values[j] > values[j+1])
            {
                int temp = values[j];
                values[j] = values[j+1];
                values[j+1] = temp;
            }
        }
    }
}
//Insert sort
void insert_sort(int values[], int n)
{
    for(int i = 1; i < n; i++)
    {
        int temp = values[i];
        for(int j = i - 1; j >= 0; j--)
        {
            if(values[j] < temp)
                break;
                
            values[j+1] = values[j];
            values[j] = temp;
        }
    }
}
//Merge sort
void merge_sort(int values[], int first, int last)
{
    if (first == last)
        return 0;
    
    int middle = (first + last) / 2;
    
    merge_sort(values, first, middle);
    merge_sort(values, middle + 1, last);
    
    int* temp;
    int j, i = l;
    j =  middle + 1;
    temp = (int*)malloc(last*sizeof(int));
    
    for( int step = 0; step < last - first + 1; step++)
    {
        if ((j>last) || ((i <= middle) && (values[i] < values[j])))
        {
            temp[step] = values[i];
            i++;
        }
        else
        {
            temp[step] = values[j];
            j++;
        }
    }
    
    for(int step = 0; step < last - first + 1; step++)
        values[first+step] = temp[step];
}
//Qiuck sort
void quick_sort(int values[], int first, int last)
{
    int middle, temp;
    int f = first, l = last;
    
    middle = values[(f + l) / 2];
    
    do
    {
        while(values[f] < middle)
            f++;
        while(values[l] > middle)
            l--;
            
        if(f <= l)
        {
            temp = values[f];
            values[f] = values[l];
            values[l] = temp;
            f++;
            f--;
        }
    } while(f < l);
    
    if( first < l)
        quick_sort(values, first, l);
    if( f < last)
        quick_sirt(values, f, last);
}